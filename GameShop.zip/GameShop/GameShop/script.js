const body = document.querySelector('body'),
	navbar = document.querySelector('nav'),
	// cart = document.querySelector('.cart-items'),
	cartBtn = document.querySelector('.cart-btn'),
	closeBtn = document.querySelectorAll('.close'),
	searchBtn = document.querySelector('.search-btn');
darkBg = document.querySelector('.overlayer');
// SearchBar
searchBtn.addEventListener('click', () => {
	navbar.classList.toggle('show-search');
	if (navbar.classList.contains('show-search')) {
		searchBtn.classList.replace('fa-search', 'fa-times')
	} else {
		searchBtn.classList.replace('fa-times', 'fa-search')
	}
	// console.log('jdh')
});
cartBtn.addEventListener('click', () => {
	navbar.classList.add('show-cart');
	// darkBg.classList.remove('opacity');

	// console.log('jdh');
});

// homepage img hover
const slides = document.querySelectorAll('.carousel-item'),
	carouselImg = document.querySelectorAll('.carousel-item img');
slides.forEach((container) => {
	carouselImg.forEach((e) => {
		// console.log(container)
		e.addEventListener('mouseover', () => {
			container.classList.add('show');
		});
		e.addEventListener('mouseout', () => {
			container.classList.remove('show');
		});
	})
});

// shop products layer
const shopItem = document.querySelectorAll('.shop-item');
shopItem.forEach((e) => {
	e.addEventListener('mouseover', () => {
		e.classList.add('show')
	})
	e.addEventListener('mouseout', () => {
		e.classList.remove('show')
	})
});

// SHOPPING CART
const addToCartBtn = document.querySelectorAll('.add-to-cart-btn'),
	cart = document.querySelector('.cart-items'),
	cartItemImg = cart.querySelectorAll('img'),
	cartItemTitle = cart.querySelectorAll('.title'),
	cartItemPrice = cart.querySelectorAll('.price');

addToCartBtn.forEach((e) => {
	e.addEventListener('click', () => {
		previewContainer.classList.add('opacity');
		previewContainer.style.display = 'none';
		darkBg.classList.add('opacity');
		darkBg.style.display = 'none';

		let parent = e.parentElement.parentElement.parentElement,
			selectedCartImg = parent.querySelector('img').src,
			selectedCartTitle = parent.querySelector('h6').textContent,
			selectedCartPrice = parent.querySelector('.current-price').textContent;
		// console.log(e.classList.contains('border'));
	});
});

// Preview Image Container Elements
const prevImgBtn = document.querySelectorAll('.shop-item');
const previewContainer = document.querySelector('.preview-container');
const prevImg = previewContainer.querySelector('img');
const prevImgCategory = previewContainer.querySelector('.category');
const prevImgTitle = previewContainer.querySelector('.product-title');
const prevImgPrevPrice = previewContainer.querySelector('.prev-price');
const prevImgCurrPrice = previewContainer.querySelector('.current-price');

// Preview Image 
// prevImgBtn.forEach((element) => {
// 	element.addEventListener('click', () => {
// 		// Selected Image Elements
// 		preview(this);


// 	});
// })

for (var i = 0; i < prevImgBtn.length; i++) {
	prevImgBtn[i].setAttribute('onclick','preview(this)')
}

function preview(element) {
	previewContainer.classList.remove('opacity');
	darkBg.classList.remove('opacity');
	body.style.overflow = 'hidden';
	
	
	let selectedImg = element.querySelector('img').src,
		selectedImgCategory = element.querySelector('.category').textContent,
		selectedImgTitle = element.querySelector('h6').textContent,
		selectedImgPrevPrice = element.querySelector('.prev-price').textContent,
		selctedImgCurrPrice = element.querySelector('.current-price').textContent;

	prevImg.src = selectedImg;
	prevImgCategory.textContent = selectedImgCategory;
	prevImgTitle.textContent = selectedImgTitle;
	prevImgPrevPrice.textContent = selectedImgPrevPrice;
	prevImgCurrPrice.textContent = `${'$'}` + selctedImgCurrPrice;


}




// Dark background
darkBg.addEventListener('click', () => {
	previewContainer.classList.add('opacity');
	body.style.overflow = 'visible';
	darkBg.classList.add('opacity');
})

// PRODUCT QUANTITY INCREASE & DECREASE
const minus = document.querySelectorAll('.minus'),
	plus = document.querySelectorAll('.plus');
//quantity = document.querySelector('.quantity');
let currentQty = 1;
// increment quantity value
for (let i = 0; i < plus.length; i++) {
	let inc = plus[i];
	let qtyArea = inc.parentElement.parentElement,
		qtyField = qtyArea.querySelector('.quantity');

	let currQty = qtyField.value;
	let increment = parseInt(currQty);
	inc.addEventListener('click', () => {
		increment++;
		qtyField.value = increment;
	})
}
// Decrement quantity value


const removeCartItemBtn = document.querySelectorAll('.remove-item');
removeCartItemBtn.forEach((e) => {
	e.addEventListener('click', () => {
		e.parentElement.parentElement.remove();
	})
})

closeBtn.forEach((e) => {
	e.addEventListener('click', () => {
		navbar.classList.remove('show-cart');

		previewContainer.classList.add('opacity');
		darkBg.classList.add('opacity');
		body.style.overflow = 'visible';
	})
})
window.addEventListener('scroll', function() {
	if (this.scrollY > 0) {
		navbar.classList.remove('show-cart');
		darkBg.classList.add('opacity');
	}
});
// click anywhere to close 
window.addEventListener('click', (e) => {
	let cartArea = document.querySelector('.cart-items'),
		searchBox = document.querySelector('.search'),
		shopArea = document.querySelector('#shop');

	const clicked = cartArea.contains(e.target) ||
		cartBtn.contains(e.target) ||
		searchBtn.contains(e.target) ||
		searchBox.contains(e.target);

	if (!clicked) {
		navbar.classList.remove('show-cart');
		navbar.classList.remove('show-search');
		searchBtn.classList.replace('fa-times', 'fa-search');
	}
});